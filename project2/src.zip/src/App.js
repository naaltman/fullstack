import React, { Component } from 'react';
import './App.css';
import FindClasses from './FindClasses'

class App extends Component {
  render() {
    return (
      <FindClasses/>
    );
  }
}

export default App;
