import React, { Component } from 'react';
import {Container, Button,
  Form, FormGroup, Label, Input, Col} from 'reactstrap';
import ClassList from './ClassList';
import './style.css'
import Select from 'react-select';
import BackgroundImage from './BackgroundImage';

class FindClasses extends Component{
  constructor(props){
    super(props);
    this.state = {semester: "Fall",
                year: "2018",
                timing: "",
                findCCC:'No CCC',
                departments: ["POLS", "WMST", "CSCI", "MATH"],
                loadSchedule: false};
    this.handleChangeYear = this.handleChangeYear.bind(this);
    this.handleChangeSemester = this.handleChangeSemester.bind(this);
    this.handleChangeCCC = this.handleChangeCCC.bind(this);
    this.handleChangeTiming = this.handleChangeTiming.bind(this);
    this.handleChangeDepartments = this.handleChangeDepartments.bind(this);
    this.shouldLoadSchedule = this.shouldLoadSchedule.bind(this);
  }

  handleChangeYear(event){
    this.setState({year: event.target.value})
  }

  handleChangeSemester(event){
    this.setState({semester: event.target.value})
  }

  handleChangeCCC(event){
    this.setState({findCCC: event.target.value})
  }

  handleChangeTiming(event){
    this.setState({timing: event.target.value})
  }

  handleChangeDepartments(event){
    console.log("target value type " + typeof(event.target.value))
    console.log("ERROR TEST Departments " + event.target.value)
    this.setState({departments: [event.target.value]})
  }

  shouldLoadSchedule(){
    console.log("prev state " + this.state.showSchedule)
    this.setState({loadSchedule: true})
    console.log("new state " + this.state.loadSchedule)
  }

  render(){
    if (!this.state.loadSchedule){
      return (<div><img src={"./planner.jpg"} alt="planner"/>
        <Col>
          <Col>
            <h1 sm={{size: 6, order: 2, offset: 3}}
              id="open-sans"><center>COURSE DESIGNER</center></h1>
          </Col>
        </Col>

        <Container>
          <Col>
          <Form id="gentium" onSubmit={this.handleSubmit}>
              <FormGroup>
                 <Label for="selectYear">WHAT YEAR IS IT?</Label>
                 <Input type="text" value = {this.state.value}
                   onChange={this.handleChangeYear} id="selectYear"
                   placeholder="Enter the Year" />
              </FormGroup>
              <FormGroup>
                <Label for="semesterSelect">WHAT SEMESTER ARE YOU PLANNING FOR?</Label>
                <Input type="select" name="select" id="semesterSelect"
                  value={this.state.semester}
                  onChange={this.handleChangeSemester}>
                  <option value="Fall">Fall</option>
                  <option value="Spring">Spring</option>
                </Input>
              </FormGroup>
              <FormGroup>
                <Label for="cccSelect">WHICH CCC REQUIREMENT ARE YOU
                                      YOU LOOKING TO FILL?</Label>
                <Input type="select" name="select" id="cccSelect"
                  onChange={this.handleChangeCCC}>
                  <option value="ARHC">Arts & Humanities</option>
                  <option value="DUSC"> Diversity in the US</option>
                  <option value="ESSC">
                    Engineering Social Science</option>
                  <option value="CCIP">IP</option>
                  <option value="LBSC">Lab Science</option>
                  <option value="NSMC">
                    Natural Science & Math</option>
                  <option value="W2">W2</option>
                  <option value="No CCC">Not Looking for a CCC</option>
                </Input>
              </FormGroup>

              <FormGroup>
                <Label for="deptSelect">WHICH DEPARTMENTS? (Select Up to 4)</Label>
                <Input type="select" name="select" id="deptSelect"
                  onClick={this.handleChangeDepartments}>
                  <option value="CSCI">Computer Science</option>
                  <option value="ECON">Economics</option>
                  <option value="ENGL">English</option>
                  <option value="ENFS">Film & Media Studies</option>
                  <option value="MATH">Math</option>
                  <option value="MIDE">MIDE</option>
                  <option value="PHYS">Physics</option>
                  <option value="POLS">Political Science</option>
                  <option value="UNIV">University Course</option>
                </Input>
              </FormGroup>
              <Col sm={{ size: 4, offset:5 }}>
                <Button onClick={this.shouldLoadSchedule} label="Action">
                  SUBMIT</Button>
              </Col>
            </Form>
            </Col>
          </Container>
        </div>
    );}
    else{
      return (<ClassList dept={this.state.departments}
        semester={this.state.semester} year={this.state.year}/>);
    }
  }
}

export default FindClasses;
